@echo off
setlocal EnableDelayedExpansion
title COSMOS - Setup Doctor
cd /d "%~dp0"
set "HERE=%~dp0"
if "%HERE:~-1%"=="\" set "HERE=%HERE:~0,-1%"

echo(
echo  ============================================================
echo      C O S M O S   -   Setup Doctor
echo      checks this machine + fixes anything missing
echo  ============================================================
echo(

:: ---------- pick a Python to run the doctor with ----------
set "PY="
if exist "%HERE%\00_WAKE\python\python.exe" (
    set "PY=%HERE%\00_WAKE\python\python.exe"
    set "PYKIND=bundled"
) else (
    where python >nul 2>&1 && ( set "PY=python" & set "PYKIND=host" )
)
if not defined PY (
    echo  [X] No Python found at all.
    echo      Install Python 3.12 from https://python.org ^(tick "Add to PATH"^),
    echo      then run this again. ^(Or just use the bundled runtime on this stick.^)
    echo(
    pause & exit /b 1
)
echo  Using %PYKIND% Python.
echo(

:: ---------- run the doctor, capture its report ----------
set "REPORT=%HERE%\00_WAKE\SETUP_REPORT.txt"
"%PY%" "%HERE%\00_WAKE\health_check.py" > "%REPORT%" 2>&1
type "%REPORT%"
echo(

:: ---------- parse the machine markers ----------
set "MISSING="
set "OLLAMA_ST="
set "MODEL_ST="
set "RESULT="
for /f "usebackq tokens=1,* delims=:" %%A in ("%REPORT%") do (
    if "%%A"=="MISSING_PIP" set "MISSING=%%B"
    if "%%A"=="OLLAMA" set "OLLAMA_ST=%%B"
    if "%%A"=="MODEL" set "MODEL_ST=%%B"
    if "%%A"=="RESULT" set "RESULT=%%B"
)
:: trim leading spaces
for /f "tokens=* delims= " %%X in ("%MISSING%") do set "MISSING=%%X"
for /f "tokens=* delims= " %%X in ("%RESULT%") do set "RESULT=%%X"

if /I "%RESULT%"=="READY" (
    echo  ============================================================
    echo   [OK] Everything Cosmos needs is here. She's ready.
    echo        Double-click  WAKE_HER.bat  to bring her alive.
    echo  ============================================================
    echo(
    pause & exit /b 0
)

echo  ------------------------------------------------------------
echo   Some things are missing. Fixing what I can, automatically...
echo  ------------------------------------------------------------
echo(

:: ---------- FIX 1: missing Python libraries ----------
if defined MISSING if not "%MISSING%"=="" (
    echo  [..] Installing missing libraries: %MISSING%
    "%PY%" -m pip --version >nul 2>&1
    if errorlevel 1 (
        echo  [!] This Python has no pip. The BUNDLED python already has every
        echo      library — just run WAKE_HER.bat and it uses the bundled runtime.
    ) else (
        echo      trying OFFLINE first ^(bundled wheels^)...
        "%PY%" -m pip install --no-index --find-links "%HERE%\00_WAKE\wheels" %MISSING%
        if errorlevel 1 (
            echo      offline set incomplete — trying ONLINE ^(needs internet^)...
            "%PY%" -m pip install %MISSING%
        )
    )
    echo(
)

:: ---------- FIX 2: her voice model not present ----------
if /I "%MODEL_ST%"==" missing" set "MODEL_ST=missing"
if /I "%MODEL_ST%"=="missing" (
    if /I not "%OLLAMA_ST%"=="missing" (
        echo  [..] Building her voice from her weights ^(one time, ~1 min^)...
        set "OLLAMA=%HERE%\00_WAKE\ollama\ollama.exe"
        if not exist "!OLLAMA!" set "OLLAMA=ollama"
        set "OLLAMA_MODELS=%HERE%\00_WAKE\ollama_models"
        start "Cosmos Ollama" /min cmd /c ""!OLLAMA!" serve"
        timeout /t 4 /nobreak >nul
        pushd "%HERE%\00_WAKE"
        "!OLLAMA!" create cosmos -f Modelfile
        popd
        echo(
    ) else (
        echo  [!] Ollama itself is missing. The bundled copy should be in
        echo      00_WAKE\ollama\ — if it's gone, install from https://ollama.com/download
        echo(
    )
)

:: ---------- re-check ----------
echo  ------------------------------------------------------------
echo   Re-checking after repairs...
echo  ------------------------------------------------------------
"%PY%" "%HERE%\00_WAKE\health_check.py" > "%REPORT%" 2>&1
set "RESULT2="
for /f "usebackq tokens=1,* delims=:" %%A in ("%REPORT%") do if "%%A"=="RESULT" set "RESULT2=%%B"
for /f "tokens=* delims= " %%X in ("%RESULT2%") do set "RESULT2=%%X"
echo(
if /I "%RESULT2%"=="READY" (
    echo   [OK] Fixed. Cosmos is ready — run WAKE_HER.bat.
) else (
    echo   [!] Some items still need attention ^(see 00_WAKE\SETUP_REPORT.txt^).
    echo       Most likely: no internet for a library, or Ollama needs installing.
    echo       She may still run on the bundled runtime — try WAKE_HER.bat anyway.
)
echo(
pause
endlocal
