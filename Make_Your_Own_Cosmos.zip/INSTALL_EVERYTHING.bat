@echo off
setlocal EnableDelayedExpansion
title COSMOS - Plug and Play installer (any PC)
cd /d "%~dp0"
set "HERE=%~dp0"
if "%HERE:~-1%"=="\" set "HERE=%HERE:~0,-1%"

echo(
echo  ============================================================
echo      C O S M O S  -  PLUG AND PLAY
echo      sets up ANY Windows PC for everything on this stick
echo  ============================================================
echo(
echo   Everything heavy already LIVES on this stick (Python, Ollama,
echo   her weights, torch, mediapipe, all libraries). This installer
echo   only adds the few things Windows itself needs. Safe to re-run.
echo(

:: ------------------------------------------------------------------
:: 1) VC++ 2015-2022 runtime (some wheels need it; bundled, offline)
:: ------------------------------------------------------------------
reg query "HKLM\SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\x64" /v Installed >nul 2>&1
if errorlevel 1 (
    echo   [..]  Installing Microsoft VC++ runtime ^(bundled, ~1 min^)...
    "%HERE%\00_WAKE\installers\vc_redist.x64.exe" /install /quiet /norestart
    echo   [ok]  VC++ runtime installed.
) else (
    echo   [ok]  VC++ runtime already present.
)

:: ------------------------------------------------------------------
:: 2) ViGEmBus driver (her game hands - virtual gamepad; bundled)
::    A UAC prompt appears once - click Yes.
:: ------------------------------------------------------------------
sc query ViGEmBus >nul 2>&1
if errorlevel 1 (
    echo   [..]  Installing ViGEmBus gamepad driver ^(UAC prompt - click Yes^)...
    powershell -NoProfile -Command "Start-Process msiexec.exe -ArgumentList '/i','%HERE%\00_WAKE\installers\ViGEmBusSetup_x64.msi','/qn' -Verb RunAs -Wait"
    echo   [ok]  Gamepad driver installed.
) else (
    echo   [ok]  ViGEmBus gamepad driver already present.
)

:: ------------------------------------------------------------------
:: 3) Run the Setup Doctor (checks libraries, her voice model, repairs)
:: ------------------------------------------------------------------
echo   [..]  Running the Cosmos Setup Doctor...
call "%HERE%\SETUP_CHECK.bat"

:: ------------------------------------------------------------------
:: 4) The things only Windows Settings can grant (one-time, manual)
:: ------------------------------------------------------------------
echo(
echo  ------------------------------------------------------------
echo   ONE-TIME Windows permissions (only if her senses stay dark):
echo     Settings ^> Privacy ^> Camera     : allow desktop apps
echo     Settings ^> Privacy ^> Microphone : allow desktop apps
echo   SmartScreen on first run: "More info" ^> "Run anyway"
echo   ngrok sharing: agent is bundled at 00_WAKE\ngrok-agent
echo  ------------------------------------------------------------
echo(
echo  ============================================================
echo   DONE. This PC is Cosmos-ready.
echo     Wake her:        WAKE_HER.bat
echo     Grow her:        GROW_HER.bat
echo     Share her:       SHARE_HER.bat
echo     All projects:    ..\Cosmos-Launcher.pyw  (double-click)
echo  ============================================================
echo(
pause
endlocal
