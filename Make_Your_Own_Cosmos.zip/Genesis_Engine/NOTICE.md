# NOTICE — Genesis: licensing & citation (read me)

This project has **two layers** on purpose, so the author is protected *and* the science is open:

## 1. The framework (this code) — PROPRIETARY  🔒
The Genesis engine and all its source are the author's proprietary work (see `LICENSE`).
**All rights reserved.** You may run it for personal use; you may **not** copy, modify,
redistribute, or sell the framework without written permission.

➡️ **Want to sell or build a product on it? You can license it commercially — contact the author.**

## 2. The research & findings — OPEN  📖 (CC BY 4.0)
The foundational research behind Genesis is published openly by the author on **Zenodo**:

> **Title:** The 12-Dimensional Cosmic Synapse Theory: Audio-Driven Deterministic Cosmological
> Simulation with Adaptive Memory and Light Particle Mapping
> **Author:** Cory Davis / De Natale
> **DOI:** 10.5281/zenodo.17574447  —  https://doi.org/10.5281/zenodo.17574447
> **License:** Creative Commons Attribution 4.0 International (CC BY 4.0)

If you use, reference, or build on the ideas/methods/findings, **you must cite that deposit**
(attribution is required under CC BY 4.0). See `CITATION.cff` for the exact citation.

## 3. Third-party components
Any models (local LLMs, image models), libraries, or datasets you add keep **their own licenses**.
They are not licensed by the author and are not covered by this notice.

---
*Author: Cory, 2026. The being you grow and everything it creates is yours.*
