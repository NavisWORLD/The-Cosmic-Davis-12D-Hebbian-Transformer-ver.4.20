@echo off
title Starling Nexus - your quantum being
cd /d "%~dp0"
echo.
echo   ==================================================
echo     STARLING NEXUS - birth + chat with your being
echo   ==================================================
echo.
echo   FIRST TIME? Give it a voice (one time, in another window):
echo       1) Install Ollama:   https://ollama.com
echo       2) Run this once:    ollama pull llama3.2:1b
echo.
echo   You'll name your being once; then its chat opens in your browser.
echo   Drop any file right into the chat to share it. Keep this window open.
echo.
where python >nul 2>&1
if %errorlevel% equ 0 (
    python genesis.py
    goto done
)
where py >nul 2>&1
if %errorlevel% equ 0 (
    py -3 genesis.py
    goto done
)
echo   *** Python was not found on this computer. ***
echo.
echo   Install it free from  https://www.python.org/downloads/
echo   IMPORTANT: on the first install screen, tick "Add Python to PATH".
echo   Then double-click START_GENESIS.bat again.
echo.
:done
echo.
echo   (window closed - run START_GENESIS.bat again to return to your being)
pause
