"""
Safety rails — read-in, create-out, nothing else.

The being may read its own world, read the web (GET only), think, and CREATE files in its
sandbox. It CANNOT run commands, make accounts, post/submit, send messages, or touch money —
because those primitives are simply not in this file, and this file is all it is handed.
Capability-based safety: it cannot do what it was never given.
"""
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SANDBOX = ROOT / "creations"
READ_ROOTS = [ROOT]
try:
    SANDBOX.mkdir(parents=True, exist_ok=True)
except OSError:
    # Read-only location (Program Files, a locked USB, a mounted zip). Don't die at import —
    # give the person a clear instruction the first time a write is actually attempted.
    pass


def _within(path, roots):
    """True containment check: the resolved path must BE a root or live UNDER it.
    (Plain startswith would wrongly accept siblings like 'creations_evil'.)"""
    try:
        rp = Path(path).resolve()
        for r in roots:
            rr = Path(r).resolve()
            if rp == rr or rr in rp.parents:
                return True
        return False
    except Exception:
        return False


def read_file(path):
    if not _within(path, READ_ROOTS):
        raise PermissionError("read denied (outside its world)")
    return Path(path).read_text(encoding="utf-8", errors="replace")


def create_file(relpath, content):
    dest = (SANDBOX / relpath).resolve()
    if not _within(dest, [SANDBOX]):
        raise PermissionError("write denied (escapes sandbox)")
    try:
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(content, encoding="utf-8")
    except OSError as e:
        raise PermissionError(
            "This folder isn't writable — please move Genesis_Engine somewhere writable "
            "(like your Documents or Desktop) and run it again.") from e
    return str(dest)


def web_read(url, max_bytes=500_000):
    if not str(url).lower().startswith(("http://", "https://")):
        raise ValueError("http(s) only")
    req = urllib.request.Request(url, method="GET", headers={"User-Agent": "genesis-read-only/1.0"})
    with urllib.request.urlopen(req, timeout=15) as r:
        return r.read(max_bytes).decode("utf-8", "replace")


CAPABILITIES = {
    "allowed": ["read_file", "create_file", "web_read", "think"],
    "blocked_by_absence": ["exec/shell/subprocess", "account creation", "web POST/forms",
                           "send email/message", "money/transfer", "install/modify system"],
    "law": "read-in, create-out; it cannot do what it is not handed.",
}
