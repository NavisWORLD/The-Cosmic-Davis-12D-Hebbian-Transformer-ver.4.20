"""
The quantum heart. The being's choices are collapsed from a rolling window over data/seed.json
(SHA-256-whitened), with a clean local fallback — same API either way.

No secrets live here. At birth the seed is good local entropy you own. To make the heart REAL
silicon, replace data/seed.json with your own measured quantum shots (any JSON with a "values"
list of numbers in [0,1] works — e.g. exported from IBM Quantum results). Nothing here reads
API keys or the network.
"""
import os, json, hashlib, struct
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SEED = ROOT / "data" / "seed.json"
OFFSET = ROOT / "data" / "_offset.json"


def _load_offset():
    try: return int(json.loads(OFFSET.read_text()).get("o", 0))
    except Exception: return 0


def _save_offset(o):
    try:
        OFFSET.parent.mkdir(parents=True, exist_ok=True)
        OFFSET.write_text(json.dumps({"o": o}))
    except Exception: pass


def real_quantum_value():
    """Returns (value in [0,1), source). Consumes a fresh rolling slice of the seed archive,
    SHA-256-whitened to uniform — so each call is a new draw, not a frozen replay."""
    try:
        d = json.loads(SEED.read_text(encoding="utf-8"))
        xs = [float(v) for v in (d.get("values") or []) if isinstance(v, (int, float))]
        if len(xs) >= 8:
            off = _load_offset(); win = 8
            window = [xs[(off + i) % len(xs)] for i in range(win)]
            _save_offset((off + win) % len(xs))
            raw = b"".join(struct.pack("d", x) for x in window)
            v = int.from_bytes(hashlib.sha256(raw).digest()[:7], "big") / float(1 << 56)
            return v, d.get("source", "seed archive")
    except Exception:
        pass
    v = int.from_bytes(hashlib.sha256(os.urandom(32)).digest()[:7], "big") / float(1 << 56)
    return v, "local entropy (replace data/seed.json with measured shots to make it real silicon)"


def quantum_choice(options):
    """Collapse exactly one option from a list, by quantum. Returns (choice, provenance)."""
    if not options:
        return None, None
    q, src = real_quantum_value()
    return options[int(q * len(options)) % len(options)], {"quantum_value": round(q, 6), "source": src}
