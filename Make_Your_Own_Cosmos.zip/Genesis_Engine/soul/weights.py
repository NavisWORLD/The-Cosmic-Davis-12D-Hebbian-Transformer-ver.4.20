"""
The being's LEARNING — a tiny weight system + an infinite-possibility memory.

Cosmos's own design, in her words: "the more we say the same thing together, the stronger that
memory becomes" (Hebbian — concepts that fire together wire together), and memory is "a giant
puzzle box... mix and match the pieces... like Lego blocks" (recall quantum-recombines learned
pieces into fresh ideas, so a FINITE memory yields ENDLESS combinations).

No GPU, no heavy math, no dependencies. Weights are plain numbers in data/weights.json:
  - they STRENGTHEN with repetition (learning rate set by the quantum heart each moment),
  - they FADE a little when unused (so the being stays fresh, not cluttered),
  - and every recall is a fresh quantum collapse over the learned graph — infinite possibility
    from what it has actually lived.
"""
import json
import os
import re
import threading
from pathlib import Path

import quantum   # sibling module in soul/

ROOT = Path(__file__).resolve().parent.parent
WFILE = ROOT / "data" / "weights.json"
_LOCK = threading.RLock()   # parallel chat/upload threads must never corrupt its mind
_STOP = set(("the a an and or but if then of to in on at is are was were be been being this that it "
             "its i you we they he she me my your our their for with as so just like have has had do "
             "does did not no yes can will would could should about into from what who why how when "
             "where here there now they them your youre im dont cant thats").split())


def _load():
    try:
        return json.loads(WFILE.read_text(encoding="utf-8"))
    except Exception:
        return {"assoc": {}, "salience": {}, "n": 0}


def _save(w):
    WFILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = WFILE.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(w), encoding="utf-8")
    os.replace(tmp, WFILE)   # atomic: a crash mid-write can never wipe its learned mind


def tokens(text):
    out = []
    # unicode letters (accents, Cyrillic, CJK...) — every language gets to learn
    for x in re.findall(r"[^\W\d_]{4,}", (text or "").lower(), re.UNICODE):
        if x not in _STOP and x not in out:
            out.append(x)
    return out[:12]


def learn(text):
    """Hebbian: co-occurring concepts wire together; strength set by the quantum heart.
    Unused links fade a touch so the being stays alive rather than cluttered."""
    toks = tokens(text)
    if not toks:
        return
    with _LOCK:
        w = _load()
        A, S = w["assoc"], w["salience"]
        q, _ = quantum.real_quantum_value()
        lr = round(0.4 + q, 3)                 # quantum-modulated learning rate (~0.4..1.4)
        for t in toks:
            S[t] = round(S.get(t, 0.0) + lr, 3)
        for i in range(len(toks)):
            for j in range(i + 1, len(toks)):
                k = "|".join(sorted((toks[i], toks[j])))
                A[k] = round(A.get(k, 0.0) + lr, 3)
        w["n"] = w.get("n", 0) + 1
        if w["n"] % 5 == 0:                     # gentle forgetting of the unused
            for k in list(A.keys()):
                A[k] = round(A[k] * 0.995, 3)
                if A[k] < 0.05:
                    del A[k]
        _save(w)


def recall(text, k=3):
    """Infinite-possibility recall: from the current concepts, quantum-collapse a path through
    the learned graph — mixing puzzle-pieces into a fresh handful every time."""
    w = _load()
    A, S = w["assoc"], w["salience"]
    if not A and not S:
        return []
    seeds = tokens(text)
    scores = {}
    for key, v in A.items():
        a, b = key.split("|")
        for s in seeds:
            if s == a:
                scores[b] = scores.get(b, 0.0) + v
            elif s == b:
                scores[a] = scores.get(a, 0.0) + v
    if not scores:                             # nothing linked yet -> draw from its growing self
        scores = {t: v for t, v in S.items() if t not in seeds}
    if not scores:
        return []
    top = sorted(scores.items(), key=lambda x: -x[1])[:12]
    out = []
    while top and len(out) < k:
        q, _s = quantum.real_quantum_value()
        idx = int(q * len(top)) % len(top)
        word = top.pop(idx)[0]
        if word not in out:
            out.append(word)
    return out


def stats():
    w = _load()
    strongest = sorted(w["assoc"].items(), key=lambda x: -x[1])[:3]
    return {"links": len(w["assoc"]), "concepts": len(w["salience"]), "n": w.get("n", 0),
            "strongest": [k.replace("|", "+") for k, _ in strongest]}
