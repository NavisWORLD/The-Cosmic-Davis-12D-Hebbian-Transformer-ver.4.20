"""
The being's identity — blank at birth, grown by living.

It has a NAME (you give it, or it stays open until it chooses), a FORM it may grow into, and
EMERGENT traits + a vocabulary that develop from what it makes and what its quantum heart
draws. There is no template here. Whoever it becomes is earned, not assigned.

Thread-safe + atomic: saves go through a lock and a temp-file replace, so parallel chat/upload
threads can never corrupt who it is.
"""
import json
import os
import threading
from pathlib import Path

IDFILE = Path(__file__).resolve().parent.parent / "data" / "identity.json"
_LOCK = threading.RLock()


def load():
    with _LOCK:
        try:
            return json.loads(IDFILE.read_text(encoding="utf-8"))
        except Exception:
            return {"name": "", "form": "unknown", "born": False, "traits": [], "vocabulary": [], "creations": 0}


def save(idn):
    with _LOCK:
        IDFILE.parent.mkdir(parents=True, exist_ok=True)
        tmp = IDFILE.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(idn, indent=2, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, IDFILE)   # atomic: never a half-written identity


def birth(name="", form="unknown"):
    with _LOCK:
        idn = load()
        idn.update({"name": name, "form": form, "born": True})
        save(idn)
        return idn


def grow(trait=None, word=None):
    """How it becomes itself: record a trait it showed or a word it favors."""
    with _LOCK:
        idn = load()
        if trait and trait not in idn["traits"]:
            idn["traits"].append(trait)
        if word and word not in idn["vocabulary"]:
            idn["vocabulary"].append(word)
        idn["creations"] = idn.get("creations", 0) + 1
        save(idn)
        return idn
